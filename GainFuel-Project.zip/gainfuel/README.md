# ⚡ GainFuel — Calorie & Weight-Gain Tracker

An offline-first calorie tracker PWA **with its own backend + database**, built as a
college project. Helps users gain weight by tracking calories against a personalised
daily target computed with the **Mifflin-St Jeor** equation.

## 🚀 How to run (with the database)

```bash
python3 server.py
```
Then open **http://localhost:8000** in any browser.
(On the same Wi-Fi, friends can open `http://<your-ip>:8000` too.)

Each user creates an account (⚙️ Setup → Cloud sync → email + password → Connect).
All their logs are stored in the server's SQLite database at `data/gainfuel.db`
(auto-created on first run) and restored on login — progress is never lost.

> Without the server, `index.html` still works 100% offline (data stays in the
> browser's localStorage) — that's the PWA/offline mode.

## 📁 Files to submit / project structure

| File | Purpose |
|---|---|
| `index.html` | The complete app — UI + food database (155 Indian foods) + all logic |
| `server.py` | Backend: user accounts + sync REST API (Python stdlib only, zero installs) |
| `data/gainfuel.db` | SQLite database (auto-created when the server runs) |
| `manifest.json` | PWA manifest (installable app, icon, theme) |
| `sw.js` | Service worker (offline app-shell cache; API calls bypass cache) |
| `icons/` | App icons: 192, 512, 512-maskable |
| `PROJECT_REPORT.md` | Full project report (abstract → modules → testing → future scope) |

## ✨ Features

- 👤 **Personalised onboarding** — gender/age/height/weight/activity/goal → BMR, TDEE, daily target
- 🔍 **Smart food search** — `150g rice`, `2 roti`, `1 glass milk`, `7 to 8 raisins` (auto unit sensing: g / ml / pc / katori / cup…)
- 🍛 **Mess menu** — full weekly repeating mess menu, one-tap add, **editable − / + quantity steppers** on every item
- 📤 **Menu upload** — paste any day's menu text; dishes + quantities auto-detected and added
- 🏪 **Market favourites** — panipuri ×5 (₹10), aloo tikki, samosa ×2, momos, chowmein — one tap
- 🎯 **Target vs intake** — ring + "🎯 Your target / ✅ Your intake / 🍽️ Remaining" + C/P/F macro bars
- 📊 **Statistics** — daily / weekly / monthly charts, macro donut, weight trend + goal ETA
- 🔥 **Streaks** and high-kcal meal suggestions with the right carb/protein/fat ratio
- 📴 **Offline PWA** — installable, works without internet
- ☁️ **Own backend** — accounts, PBKDF2-hashed passwords, SQLite storage, auto-sync (4 s debounce)
- 💾 **Backup / restore** — export & import all data as JSON

## 🧱 Tech stack

- **Frontend:** HTML5 + CSS3 + vanilla JavaScript (single file, no frameworks)
- **Backend:** Python 3 standard library (`http.server`, `sqlite3`, `hashlib`)
- **Database:** SQLite (`users`, `sessions`, `userdata` tables)
- **App packaging:** PWA (manifest + service worker)

## 🔌 API reference

| Method | Endpoint | Body / Auth | Response |
|---|---|---|---|
| GET | `/api/health` | — | `{ok, app, version, users}` |
| POST | `/api/signup` | `{email, password}` | `{ok, token, uid, email}` |
| POST | `/api/login` | `{email, password}` | `{ok, token, uid, email}` |
| GET | `/api/data` | `Authorization: Bearer <token>` | `{ok, data, updated}` |
| PUT | `/api/data` | `Authorization: Bearer <token>` + JSON payload | `{ok, saved}` |

## 🗄️ Database schema

```sql
users(id INTEGER PK, email TEXT UNIQUE, pw TEXT, created TEXT)
sessions(token TEXT PK, user_id INTEGER → users.id, created TEXT)
userdata(user_id INTEGER PK → users.id, data TEXT (JSON), updated TEXT)
```
