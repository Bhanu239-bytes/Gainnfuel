#!/usr/bin/env python3
"""
GainFuel — built-in backend server with its own SQLite database.
Zero dependencies (Python standard library only).

What it does
------------
1. Serves the GainFuel app (index.html, manifest.json, sw.js, icons/) on port 8000
2. Provides a small REST API for user accounts + cloud sync:
     GET  /api/health          -> server status
     POST /api/signup          {email, password} -> {token, uid, email}
     POST /api/login           {email, password} -> {token, uid, email}
     GET  /api/data            (Authorization: Bearer <token>) -> saved user data
     PUT  /api/data            (Authorization: Bearer <token>) <- save user data
3. Stores everything in SQLite: data/gainfuel.db (auto-created)

Run
---
    python3 server.py
    -> open http://localhost:8000   (on your network: http://<your-ip>:8000)

Data survives restarts because it lives in data/gainfuel.db on disk.
Each user's data is private — protected by their email + password (PBKDF2-hashed).
"""
import json
import os
import re
import sqlite3
import hashlib
import hmac
import secrets
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(ROOT, "data", "gainfuel.db")
PORT = int(os.environ.get("PORT", "8000"))
MAX_BODY = 8 * 1024 * 1024  # 8 MB per request

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".webmanifest": "application/manifest+json",
    ".txt": "text/plain; charset=utf-8",
    ".md": "text/plain; charset=utf-8",
    ".woff2": "font/woff2",
}


# --------------------------------------------------------------------------- db
def db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    with db() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                email   TEXT UNIQUE NOT NULL,
                pw      TEXT NOT NULL,
                created TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token   TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS userdata (
                user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                data    TEXT NOT NULL,
                updated TEXT DEFAULT (datetime('now'))
            );
            """
        )


def hash_pw(pw: str, salt: str = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 120_000).hex()
    return salt + "$" + digest


def check_pw(pw: str, stored: str) -> bool:
    try:
        salt = stored.split("$", 1)[0]
    except ValueError:
        return False
    return hmac.compare_digest(hash_pw(pw, salt), stored)


# ---------------------------------------------------------------------- handler
class Handler(BaseHTTPRequestHandler):
    server_version = "GainFuelServer/1.0"
    protocol_version = "HTTP/1.1"

    # ---- helpers ----------------------------------------------------------
    def _reply(self, code: int, obj) -> None:
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict:
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        n = min(n, MAX_BODY)
        raw = self.rfile.read(n) if n else b""
        try:
            obj = json.loads(raw or b"{}")
            return obj if isinstance(obj, dict) else {}
        except Exception:
            return {}

    def _user(self):
        """Return (id, email) from the Bearer token, or None."""
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return None
        token = auth[7:].strip()
        if not token:
            return None
        with db() as c:
            row = c.execute(
                "SELECT u.id, u.email FROM sessions s "
                "JOIN users u ON u.id = s.user_id WHERE s.token = ?",
                (token,),
            ).fetchone()
        return tuple(row) if row else None

    def log_message(self, fmt, *args):  # quieter logs
        print("[gainfuel] %s - %s" % (self.address_string(), fmt % args))

    # ---- API --------------------------------------------------------------
    def api_health(self):
        users = 0
        with db() as c:
            users = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        self._reply(200, {"ok": True, "app": "gainfuel", "version": 1, "users": users})

    def api_signup(self, body):
        email = str(body.get("email", "")).strip().lower()
        pw = str(body.get("password", ""))
        if not EMAIL_RE.match(email):
            return self._reply(400, {"error": "Enter a valid email address"})
        if len(pw) < 6:
            return self._reply(400, {"error": "Password must be at least 6 characters"})
        with db() as c:
            try:
                cur = c.execute(
                    "INSERT INTO users(email, pw) VALUES(?, ?)", (email, hash_pw(pw))
                )
                uid = cur.lastrowid
            except sqlite3.IntegrityError:
                return self._reply(409, {"error": "Account already exists — please log in"})
            token = secrets.token_hex(32)
            c.execute("INSERT INTO sessions(token, user_id) VALUES(?, ?)", (token, uid))
        self._reply(200, {"ok": True, "token": token, "uid": uid, "email": email})

    def api_login(self, body):
        email = str(body.get("email", "")).strip().lower()
        pw = str(body.get("password", ""))
        with db() as c:
            row = c.execute("SELECT id, pw FROM users WHERE email = ?", (email,)).fetchone()
        if not row or not check_pw(pw, row[1]):
            return self._reply(401, {"error": "Wrong email or password"})
        token = secrets.token_hex(32)
        with db() as c:
            c.execute("INSERT INTO sessions(token, user_id) VALUES(?, ?)", (token, row[0]))
        self._reply(200, {"ok": True, "token": token, "uid": row[0], "email": email})

    def api_get_data(self):
        user = self._user()
        if not user:
            return self._reply(401, {"error": "Not logged in"})
        with db() as c:
            row = c.execute(
                "SELECT data, updated FROM userdata WHERE user_id = ?", (user[0],)
            ).fetchone()
        if not row:
            return self._reply(200, {"ok": True, "data": None, "updated": None})
        try:
            data = json.loads(row[0])
        except Exception:
            data = None
        self._reply(200, {"ok": True, "data": data, "updated": row[1]})

    def api_put_data(self):
        user = self._user()
        if not user:
            return self._reply(401, {"error": "Not logged in"})
        body = self._body()
        if not isinstance(body, dict) or not body:
            return self._reply(400, {"error": "Empty payload"})
        with db() as c:
            c.execute(
                "INSERT INTO userdata(user_id, data, updated) VALUES(?, ?, datetime('now')) "
                "ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, "
                "updated = datetime('now')",
                (user[0], json.dumps(body)),
            )
        self._reply(200, {"ok": True, "saved": True})

    # ---- routing ----------------------------------------------------------
    def _route_api(self, method: str) -> None:
        path = self.path.split("?")[0]
        if method == "GET" and path == "/api/health":
            return self.api_health()
        if method == "POST" and path == "/api/signup":
            return self.api_signup(self._body())
        if method == "POST" and path == "/api/login":
            return self.api_login(self._body())
        if method == "GET" and path == "/api/data":
            return self.api_get_data()
        if method == "PUT" and path == "/api/data":
            return self.api_put_data()
        self._reply(404, {"error": "Unknown API endpoint"})

    # ---- static files -----------------------------------------------------
    def _serve_static(self) -> None:
        path = self.path.split("?")[0]
        if path == "/":
            path = "/index.html"
        full = os.path.realpath(os.path.join(ROOT, path.lstrip("/")))
        if not full.startswith(ROOT + os.sep) and full != os.path.join(ROOT, "index.html"):
            return self._reply(403, {"error": "Forbidden"})
        if not os.path.isfile(full):
            return self._reply(404, {"error": "Not found"})
        ext = os.path.splitext(full)[1].lower()
        with open(full, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", MIME.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        if ext in (".html", ".json", ".webmanifest"):
            self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    # ---- HTTP verbs -------------------------------------------------------
    def do_GET(self):
        if self.path.startswith("/api/"):
            return self._route_api("GET")
        return self._serve_static()

    def do_POST(self):
        if self.path.startswith("/api/"):
            return self._route_api("POST")
        self._reply(404, {"error": "Not found"})

    def do_PUT(self):
        if self.path.startswith("/api/"):
            return self._route_api("PUT")
        self._reply(404, {"error": "Not found"})

    def do_DELETE(self):
        self._reply(404, {"error": "Not found"})

    def do_HEAD(self):
        self.do_GET()


def main():
    init_db()
    addr = ("0.0.0.0", PORT)
    httpd = ThreadingHTTPServer(addr, Handler)
    print(f"GainFuel server running  ->  http://localhost:{PORT}")
    print(f"Database file            ->  {DB_PATH}")
    print("Press Ctrl+C to stop.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nBye!")


if __name__ == "__main__":
    main()
