# PROJECT REPORT — GainFuel

**Project title:** GainFuel — A Personalised Calorie & Weight-Gain Tracker with Offline Support and Cloud Accounts

**Type:** Mini project / Major project (web + database)
**Domain:** Health-tech, Full-stack web development

---

## 1. Abstract

GainFuel is a calorie-tracking web application that helps underweight users gain
weight in a controlled, scientific way. Unlike generic calorie apps that assume a
fixed 2000 kcal diet and western foods, GainFuel (a) computes a **personalised daily
calorie target** for every user using the Mifflin-St Jeor equation, (b) ships with a
**database of 155 Indian foods** (including mess items and street food) with automatic
unit sensing (grams / millilitres / pieces / katori / bowl…), (c) lets the user log
meals **without typing** through weekly mess-menu presets and one-tap market
favourites, and (d) works **completely offline** as an installable PWA, with an
optional **own backend (Python + SQLite)** providing user accounts and multi-device
data sync. The app always shows the user's calorie **target side-by-side with actual
intake and remaining calories**, and visualises daily/weekly/monthly progress with
graphs and a weight-trend chart with goal ETA.

## 2. Objectives

1. Compute each individual's daily calorie need with high accuracy (BMR → TDEE → goal adjustment).
2. Remove the typing barrier: meal logging via presets (hostel mess menu, market favourites) and paste-to-parse menu upload.
3. Make every quantity editable — the user logs what they *actually* ate, never a fixed portion.
4. Show both *eaten* and *required* calories at all times, with macro (carb/protein/fat) breakdown.
5. Guarantee zero data loss: offline localStorage + accounts with a server-side SQLite database.
6. Package as an installable app (PWA) ready for Android/Play-Store distribution.

## 3. Existing system vs proposed system

| Existing systems (generic trackers) | GainFuel (proposed) |
|---|---|
| Western food databases, per-100g only | 155 Indian foods; g/ml/pc/katori/bowl/cup auto-sensing |
| Manual search + typing for every meal | Weekly mess-menu presets, one-tap market items, paste-menu auto-detect |
| Fixed serving sizes | Every quantity editable via − / + steppers |
| Single generic calorie goal | Personalised Mifflin-St Jeor BMR/TDEE + goal adjustment |
| Require internet account signup | Offline-first PWA; cloud accounts optional |
| No storage control | Local storage **and** own backend with SQLite |

## 4. Modules

1. **Onboarding & Target module** — collects gender, age, height, weight, activity level, goal; computes BMR (Mifflin-St Jeor), TDEE (activity factor) and goal-adjusted target (+750 fast gain / +400 gain / 0 maintain / −500 lose); shows live preview before saving.
2. **Food database module** — 155 foods with per-100 g (or per-piece) kcal and macros; alias search ("dal", "chawal", "panipuri"); custom foods; unit auto-sensing from natural text like `150g rice`, `2 glass milk`, `7 to 8 raisins`.
3. **Mess menu module** — full weekly repeating mess menu (Mon–Sun, breakfast/lunch/snacks/dinner); one-tap add to the correct meal; editable − / + quantity steppers on every row so 4 kachori can be logged as 2.
4. **Menu-upload module** — user pastes the day's menu as plain text; the parser strips meal headers, detects dish names and quantities, matches them to the database (preferring cooked variants for katori/bowl servings), and shows a review list with editable quantities before adding.
5. **Market favourites module** — one-tap logging of street-food habits (panipuri ×5 ≈ ₹10, aloo tikki, samosa ×2, momos, chowmein).
6. **Statistics module** — today ring + macro bars; daily (7-day), weekly (per-day totals over 12 weeks), monthly (per-week totals over 12 months) charts; macro donut; weight-trend line chart with goal ETA projection; streak counter.
7. **Sync & storage module** — three tiers: (i) localStorage for instant offline persistence, (ii) built-in GainFuel server (Python) with SQLite and email/password accounts, (iii) optional Supabase for scale; autosync 4 s after every change; JSON export/import backup.
8. **PWA module** — manifest.json, service worker (app-shell cache, offline fallback; API routes bypass cache), icons 192/512/maskable, installable on Android/iOS/desktop.

## 5. Technology used

- HTML5, CSS3, vanilla JavaScript (ES2020) — single-file frontend, no framework
- Canvas 2D for all charts (no chart library needed)
- Python 3 standard library: `http.server` (REST API), `sqlite3` (database), `hashlib.pbkdf2_hmac` (password hashing), `secrets` (session tokens)
- SQLite relational database: `users`, `sessions`, `userdata` tables
- Progressive Web App: `manifest.json`, `sw.js` service worker

## 6. Database design

```
users(id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      pw    TEXT NOT NULL,              -- salt$pbkdf2-sha256(120k iterations)
      created TEXT DEFAULT now)

sessions(token TEXT PRIMARY KEY,        -- 256-bit random token
         user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
         created TEXT DEFAULT now)

userdata(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
         data TEXT NOT NULL,            -- JSON: profile, settings, presets,
         updated TEXT DEFAULT now)      --        customFoods, entries, weights
```

Security: passwords are never stored in plain text (PBKDF2-SHA256, 120 000
iterations, random 16-byte salt); sessions use 256-bit random bearer tokens;
every `/api/data` request is authenticated; client-side localStorage is only a cache.

## 7. Testing

| # | Test case | Result |
|---|---|---|
| 1 | App boots with 155 foods; no console errors | ✅ Pass |
| 2 | Energy math: 21 y male, 175 cm, 45 kg, sedentary, fast-gain → BMR 1444, TDEE 1733, target 2483 kcal | ✅ Pass |
| 3 | Parse `150g rice`, `2 roti`, `1 glass milk`, `7 to 8 raisins` → correct food/qty/unit | ✅ Pass |
| 4 | Paste `lunch: 1 katori dal, 2 roti, rice` → 3 rows auto-detected, dal resolves to *cooked* | ✅ Pass |
| 5 | Steppers: reduce 4 aloo kachori → 2, kcal recalculated | ✅ Pass |
| 6 | API: signup → duplicate signup rejected (409) → login → wrong password rejected (401) | ✅ Pass |
| 7 | Sync: push data → new session login → pull restores profile/entries/weights | ✅ Pass |
| 8 | Security: bad token → 401; path traversal `../` → 403 | ✅ Pass |
| 9 | Offline: airplane mode → app loads from SW cache, logs saved locally, syncs when back online | ✅ Pass |
| 10 | Node `--check` syntax validation of the full app script | ✅ Pass |

## 8. Results

- Personalised target computed instantly for any user (validated against standard Mifflin-St Jeor examples).
- Full meal logging without keyboard: mess presets + market favourites + paste-menu parsing all functional.
- Zero data loss demonstrated: data survives server restart via SQLite and re-login restores everything on a new device.
- PWA installs on Android (Add to Home screen) and runs fully offline.

## 9. Future scope

- Photo → menu using a cloud vision API (OCR) for handwritten mess menus
- Hindi / regional-language UI
- Barcode scanning for packaged foods
- Play-Store publication via PWABuilder (TWA packaging)
- Dietitian-approved meal plans and weight-gain programs
- Trainer/warden dashboard for hostel mess analytics

## 10. Conclusion

GainFuel demonstrates a complete, production-style health app: a framework-free
frontend, a real backend with secure account storage, offline-first design, and a
user experience tailored to Indian hostel/street-food habits. It meets all stated
objectives and is ready for deployment and store packaging.
